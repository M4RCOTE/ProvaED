using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao3
{
    class Lista<T>
    {
        
        //atributos
        NoLista<T> inicio;
        NoLista<T> fim;

        //construtor
        public Lista(){
            inicio = null;
            fim = null;
        }

        //getters e setters

        public void setProx(NoLista<T> inicio_){
            inicio = inicio_;
        }
        public void setAntes(NoLista<T> fim_){
            fim = fim_;
        }

        public NoLista<T> getProx(){
            return inicio;
        }
        public NoLista<T> getAntes(){
            return fim;
        }


        //métodos
        public bool estaVazia()
        {

            if(inicio == null){
                return true;
            }

            return false;
        }

        public int tamanho()
        {
            if(estaVazia()){return 0;}
            
            int i = 0;
            NoLista<T> temp = inicio;

            while(temp != null){
                temp = temp.getProx();
                i++;
            }
            
            return i;
        }

        public void imprime()
        {
            NoLista<T> temp = inicio;
            
            while(temp != null){
                Console.Write(temp.getValor() + " ");
                temp = temp.getProx();
            }

        }
    
        public void insere(T dado)
        {
            NoLista<T> novo = new NoLista<T>(dado);

            if (estaVazia()){
                inicio = novo;
                fim = novo;
            }else{
                NoLista<T> temp = inicio;
            
                while(temp != null){
                    
                    if (Convert.ToDouble(dado) < Convert.ToDouble(inicio.getValor())){
                        
                        inicio.setAntes(novo);
                        novo.setProx(inicio);
                        inicio = novo;
                        break;
                    
                    }else if(Convert.ToDouble(dado) < Convert.ToDouble(temp.getValor())){
                        
                        NoLista<T> antes = temp.getAntes();

                        antes.setProx(novo);
                        novo.setAntes(antes);
                        
                        temp.setAntes(novo);
                        novo.setProx(temp);


                        break;
                    }else if(temp == fim){
                        temp.setProx(novo);
                        novo.setAntes(temp);

                        fim = novo;
                        break;
                    }
                    temp = temp.getProx();
                }
            }
        }

        public void remove(T dado)
        {
            NoLista<T> temp = inicio;
            
                while(temp != null){
                    
                    if(Convert.ToDouble(dado) == Convert.ToDouble(temp.getValor())){

                        temp.getAntes().setProx(temp.getProx());
                        temp.getProx().setAntes(temp.getAntes());

                        break;
                    }
                    temp = temp.getProx();
                }
        }

        



        
    } 
}
