﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao3
{
    class Program
    {
        static void Main(string[] args)
        {
            Lista<double> LD = new Lista<double>();

            Console.Clear();
            LD.insere(2.5);
            LD.insere(8.9);
            LD.insere(4.3);
            LD.insere(3.8);
            LD.imprime();
            
            Console.ReadLine();
            
        }

    } 
}
