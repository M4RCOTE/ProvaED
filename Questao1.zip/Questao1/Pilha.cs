﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao1
{
    class Pilha<T>
    {
        NoPilha<T> topo;

        public Pilha(){ 
            topo = null;
        }

        public void push(T n){
            NoPilha<T> novoNo = new NoPilha<T>(n);

            if (this.estaVazia()){
                topo = novoNo;
            }
            else{
                novoNo.setProx(topo);
                topo = novoNo;
            }

        }

        public T pop(){
            T a = topo.getValor();

            if(!estaVazia()){
                topo = topo.getProx();
                return a;
            }
            return a;
        }


        public void imprime(){
            NoPilha<T> a = topo;
            
            while(a != null){
                Console.WriteLine(a.getValor());
                a = a.getProx();
            }

        }

        public bool estaVazia(){
            if(topo == null)
                return true;
            return false;
        }


    } // fim da classe Pilha
}
