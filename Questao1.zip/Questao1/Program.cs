﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Questao1
{

    class Program {



        static void Main(string[] args) {

            Console.Clear();

            string t1 = "{ 5 * [ a + b] – d * (c – a) + log10 }";
            string t2 = "{ 5 * [ a + b] – d * (c – a] + log10 } ";

            Console.WriteLine("Expressão " + t1 + " está sintaticamente correta? " + VerificarSintaxe(t1));
            Console.WriteLine("\nExpressão " + t2 + "está sintaticamente correta? " + VerificarSintaxe(t2));

            int aux = 0;
            while (aux == 0){
                
                
                
                Console.WriteLine("\nEscreva outra expressão (digite 0 pra sair): ");
                string expressao1 = Console.ReadLine();

                if(expressao1 == "0"){
                    aux = 1;
                    break;
                }

                Console.WriteLine("Expressão está sintaticamente correta? " + VerificarSintaxe(expressao1));
                Console.ReadLine();
            }
        }

        static bool VerificarSintaxe(string expressao) {
            Pilha<char> pilha = new Pilha<char>();

            foreach (char caractere in expressao) {
                if (caractere == '{' || caractere == '[' || caractere == '(') {
                    pilha.push(caractere);
                }
                else if (caractere == '}' || caractere == ']' || caractere == ')') {
                    if (pilha.estaVazia()) {
                        return false;
                    }
                    char topo = pilha.pop();
                    if ((caractere == '}' && topo != '{') || (caractere == ']' && topo != '[') || (caractere == ')' && topo != '(')) {
                        return false;
                    }
                }
            }

            return pilha.estaVazia();
        }
    }
}


