using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao2
{
    class NoPilha

    {
        //Atributos
        int valor;
        NoPilha prox;


        //Construtores
        public NoPilha(){
            valor = 0;
            prox = null;
        }
        public NoPilha(int a){
            valor = a;
            prox = null;
        }
        public NoPilha(int a, NoPilha b){
            valor = a;
            prox = b;
        }

        //Getters and Setters
        public void setProx(NoPilha a){
            prox = a;
        }
        public void setValor(int a){
            valor = a;
        }

        public NoPilha getProx(){
            return prox;
        }
        public int getValor(){
            return valor;
        }

        
    } // fim da classe Pilha
}
