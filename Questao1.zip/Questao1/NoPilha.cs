using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao1
{
    class NoPilha <T> 

    {
        //Atributos
        T valor;
        NoPilha<T> prox;


        //Construtores
        public NoPilha(){
            prox = null;
        }
        public NoPilha(T a){
            valor = a;
            prox = null;
        }
        public NoPilha(T a, NoPilha<T> b){
            valor = a;
            prox = b;
        }

        //Getters and Setters
        public void setProx(NoPilha<T> a){
            prox = a;
        }
        public void setValor(T a){
            valor = a;
        }

        public NoPilha<T> getProx(){
            return prox;
        }
        public T getValor(){
            return valor;
        }

        
    } // fim da classe Pilha
}
