﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Questao2
{
    class Program {
        static void Main(string[] args) {
            
            Pilha estacionamento = new Pilha();
            
            int aux = 1;

            while (aux != 0)
            {
                Console.Clear();

                Console.WriteLine("Escolha uma opção do menu :\n");
                Console.WriteLine(" [1] - Inserir carro no estacionamento");
                Console.WriteLine(" [2] - Retirar carro do estacionamento");
                Console.WriteLine(" [3] - Imprimir todos elementos da fila");
                Console.WriteLine(" [4] - Sair");

                string op = Console.ReadLine();

                switch (op)
                {
                    case "1":

                        if(estacionamento.tam() == 10){
                            Console.WriteLine("Não há vagas no estacionamento");
                        }else{
                            Console.WriteLine("Há vagas no estacionamento");
                            Console.Write("Digite o código (int) do carro: ");
                            int ele = Convert.ToInt32(Console.ReadLine());

                            Console.Write("O carro de código "+ ele+ " chegou no estacionamento");
                            estacionamento.push(ele);
                        }
                        Console.ReadLine();
                        Console.Clear();
                    
                        break;

                    case "2":
                        
                        int key = 0;
                        try{
                            if(estacionamento.estaVazia()){
                                Console.WriteLine("Estacionamento vazio");
                            }else{
                                Console.WriteLine("Digite o código (int) do carro:");
                                int ele = Convert.ToInt32(Console.ReadLine());

                                estacionamento.remove(ele);
                                Console.WriteLine("O carro de código "+ ele+ " partiu do estacionamento");
                                key = 1;
                            }
                        }catch{
                    
                            if(key == 0){
                                Console.WriteLine("Não tem um carro com esse código");
                            }
                        }
                        
                        Console.ReadLine();
                        Console.Clear();
                        break;

                    case "3":
                        estacionamento.imprime();
                        Console.ReadLine();
                        Console.Clear();
                        break;

                    case "4":
                        aux = 0;
                        Console.Clear();
                        break;
                    default:
                        Console.Write("Favor selecionar uma das opções mostradas no menu\n");
                        break;
                }
            }
        }

        
    }

} 

