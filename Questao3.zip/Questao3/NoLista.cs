using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao3
{
    class NoLista<T>
    {
        //atributos
        T dado;
        NoLista<T> prox;
        NoLista<T> antes;

        //construtores
        public NoLista(){;
            prox = null;
            antes = null;
        }
        public NoLista(T dado_){
            dado = dado_;
            prox = null;
            antes = null;
        }
        public NoLista(T dado_, NoLista<T> prox_){
            dado = dado_;
            prox = prox_;
            antes = null;
        }
        public NoLista(T dado_, NoLista<T> prox_, NoLista<T> antes_ ){
            dado = dado_;
            prox = prox_;
            antes = antes_;
        }

        //Getters and Setters
        public void setValor(T dado_){
            dado = dado_;
        }
        public void setProx(NoLista<T> prox_){
            prox = prox_;
        }
        public void setAntes(NoLista<T> antes_){
            antes = antes_;
        }

        public T getValor(){
            return dado;
        }
        public NoLista<T> getProx(){
            return prox;
        }
        public NoLista<T> getAntes(){
            return antes;
        }
    } 
}
