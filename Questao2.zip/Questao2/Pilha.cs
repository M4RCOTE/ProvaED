﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao2
{
    class Pilha
    {
        NoPilha topo = new NoPilha();

        public Pilha(){ 
            topo = null;
        }


        public NoPilha getTopo(){
            return topo;
        }

        public void push(int n){
            NoPilha novoNo = new NoPilha(n);

            if (this.estaVazia()){
                topo = novoNo;
            }
            else{
                novoNo.setProx(topo);
                topo = novoNo;
            }

        }

        public int pop(){
            int a = topo.getValor();

            if(!estaVazia()){
                topo = topo.getProx();
                return a;
            }
            return 0;
        }


        public void imprime(){
            NoPilha a = topo;
            string pilha = "";

            while(a != null){
                pilha = pilha + a.getValor() + " ";
                a = a.getProx();
            }

            Console.WriteLine("\n" + reverseString(pilha));

        }

        private string reverseString(string Word){
            char[] arrChar = Word.ToCharArray();
            Array.Reverse(arrChar);
            string invertida = new String(arrChar);

           return invertida;
        }

        public int tam(){
            NoPilha a = topo;
            int i = 0;

            while(a != null){
                i++;
                a = a.getProx();
            }
            return i;

        }

        public bool estaVazia(){
            if(topo == null)
                return true;
            return false;
        }
        
        public void remove(int dado){
            NoPilha temp = topo;

            while(temp != null){
                
                if(topo.getValor() == dado){
                    topo = topo.getProx();
                }
                else if(temp.getProx().getValor() == dado){

                    temp.setProx(temp.getProx().getProx());
                }
                temp = temp.getProx();
            }
        }



    } // fim da classe Pilha
}
